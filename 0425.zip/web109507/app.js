var createError = require('http-errors');
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var index = require('./routes/index');
var users = require('./routes/users');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

//------------------------------------------------------------
// user
//------------------------------------------------------------
var user_add_form = require('./routes/user_add_form'); //新增
var user_add = require('./routes/user_add');

var user_remove_form = require('./routes/user_remove_form');  //刪除
var user_remove = require('./routes/user_remove');

var user_query_form = require('./routes/user_query_form');  //查詢
var user_query = require('./routes/user_query');

var user_update_no = require('./routes/user_update_no');  //更新
var user_update_form = require('./routes/user_update_form');
var user_update = require('./routes/user_update');


var app = express();


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// uncomment after placing your favicon in /public
//app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', index);
app.use('/users', users);

app.use('/', indexRouter);
app.use('/users', usersRouter);

//-----------------------------------------
// user
//-----------------------------------------
app.use('/user/add/form', user_add_form); //新增
app.use('/user/add', user_add);

app.use('/user/remove/form', user_remove_form); //刪除
app.use('/user/remove', user_remove);

app.use('/user/query/form', user_query_form); //查詢
app.use('/user/query', user_query);

app.use('/user/update/no', user_update_no); //更新
app.use('/user/update/form', user_update_form);
app.use('/user/update', user_update);


// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
