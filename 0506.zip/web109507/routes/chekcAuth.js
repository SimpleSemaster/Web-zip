var express = require('express');
var router = express.Router();

//增加引用函式
const user = require('./utility/user');

//接收GET請求
router.get('/', function(req, res, next) {
    var email = req.session.profile.getEmail(); 

    var schemail = req.body.schemail;         //取得帳號
    var isEmployee = req.body.isEmployee;     //取得是否為員工

    if(email === schemail){
        if(isEmployee === 1){
            alert("無權利使用");
        }
    }else{
        alert('非本系師生');
    }
});

module.exports = router;