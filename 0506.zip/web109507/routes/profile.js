var express = require('express');
var router = express.Router();

//接收GET請求
router.get('/', function(req, res, next) {
    var email = req.session.getmail;
    var schemail = req.session.schemail;
    if(email === schemail){
        alert("無權利使用");
    }else{
        alert('非本系師生');
    }
});

module.exports = router;