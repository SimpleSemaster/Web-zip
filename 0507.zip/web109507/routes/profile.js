var express = require('express');
var router = express.Router();

//接收GET請求
router.get('/', function(req, res, next) {
    var schemail = req.body.schemail;    //資料庫
    var useremail = req.session.useremail;         //第三方登入取得
    var signOut = req.session.signOut;

    if(useremail === null){
        alert("請先登入");
    }else if(useremail === schemail){
        alert("登入成功");
    }else{
        alert("非本系師生");
        signOut;
    }    
});

module.exports = router;