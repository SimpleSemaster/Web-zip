var express = require('express');
var router = express.Router();

//處理GET, POST, PUT, DELETE等所有請求
router.all('/', function(req, res, next) {
    //檢查是否有session註記
    var isE = req.body.isEmployee;   //是否為員工
    var schemail = req.body.schemail;    //資料庫
    var useremail = req.session.useremail;     //第三方登入取得
    
    if(useremail == schemail && isE == f){               //不是員工，則不可以使用
        alert("無權利使用");
        res.render('index');   
    }else{
        next();  //執行在app.use()中, 串接在checkAuth之後的函式 
    }    
});

module.exports = router;