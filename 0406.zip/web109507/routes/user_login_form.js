var express = require('express');
var router = express.Router();

//接收GET請求
router.get('/', function(req, res, next) {
    var username = req.session.username ;
    if(username == null){
        res.render('user_login_form');
    }else{
        res.render('user_show',{name:username})
    }
});

module.exports = router; 