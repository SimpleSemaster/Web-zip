var express = require('express');
var router = express.Router();

//增加引用函式
const user = require('./utility/user');

//接收POST請求
router.post('/', function(req, res, next) {
    var id = req.body.schemail;                 //取得帳號
    var password = req.body.password;           //取得密碼

    user.login(id, password).then(d => {
        if (d==null){
            req.session.schemail = null;
            req.session.username = null;           
            res.render('loginFail');  //傳至登入失敗
        }else{
            req.session.schemail = d.schemail;
            req.session.username = d.username;
            res.render('user_show', {name:d.username});   //導向使用者
        }  
    })
});

// for google oauth
router.get("/google", function(req, res, next){
    var google_oauth_url = "https://accounts.google.com/o/oauth2/v2/auth?" +  
    //Scope可以參考文件裡各式各樣的scope，可以貼scope url或是個別命名
    "scope=email%20profile&"+
    "redirect_uri=http://localhost/google/callback&"+
    "response_type=code&"+
    "client_id=" + google_client_id;
    res.send(JSON.stringify({"redirect_url":google_oauth_url}));
});
router.get("/google/callback", function(req, res) {
    var code = req.query.code;
    //拿code換token
    var token_option = {
        url:"https://www.googleapis.com/oauth2/v4/token",
        method:"POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        form:{
            code: code,
            client_id: '11686802778-1uhbpv4706p3an8anm8qs4dcah4v7t4n.apps.googleusercontent.com',
            client_secret: '82gW3jPvKOVPPUzqt9bCW-SN',
            grant_type:"authorization_code",
            //要跟Google Console裡填的一樣喔
            redirect_uri:"http://localhost/google/callback"
        }
    };
    request(token_option, function(err, resposne, body) {
        var access_token = JSON.parse(body).access_token;
        var info_option = {
            url:"https://www.googleapis.com/oauth2/v1/userinfo?"+"access_token="+access_token,
            method:"GET",
        };
        request(info_option, function(err, response, body){
            if(err){
                res.send(err);
            }
            res.send(body);
        });
    })
});

module.exports = router;