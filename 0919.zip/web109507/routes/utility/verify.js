'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
//執行資料庫動作的函式-商品
//------------------------------------------
var query = async function(yesorno){
    var result={};

    await sql('SELECT * FROM bookingroom WHERE yesorno is null or yesorno = $1', [yesorno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
      
    await sql('SELECT * FROM "bookingroomdetail" WHERE "bookingroomno" = $1', [result.bookingroomno])
        .then((data) => {
            if(data.rows.length > 0){
                result.roomno = data.rows[0].roomno;   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });  
          
    console.log(result);
    
    return result;
}

//----------------------------------
// 更新商品
//----------------------------------
var update = async function(newData){
    var results;

    await sql('UPDATE bookingroom SET yesorno=$1 WHERE userno = $2', [newData.yesorno, newData.userno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}

//------------------------------------------
//執行資料庫動作的函式-取出單一商品
//------------------------------------------
var query_no = async function(userno){
    var result={};
    
    await sql('SELECT * FROM bookingroom WHERE userno = $1', [userno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
        
    await sql('SELECT * FROM "bookingroomdetail" WHERE "bookingroomno" = $1', [result.bookingroomno])
        .then((data) => {
            if(data.rows.length > 0){
                result.roomno = data.rows[0].roomno;   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });  
    
		
    return result;
}

//匯出
module.exports = {query, update, query_no};