'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
// 新增商品
//------------------------------------------
var add = async function(newData){
    var result;

    await sql('INSERT INTO bookingroom (userno, reason, bookingdate, borrowdate, endate) VALUES ($1, $2, $3, $4, $5)', [newData.userno, newData.reason, newData.bookingdate, newData.borrowdate, newData.endate])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
		
    return result;
}

var add_detail = async function(newData){
    var result;

    await sql('INSERT INTO bookingroomdetail (roomno) VALUES ($1)', [newData.roomno])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
		
    return result;
}


//匯出
module.exports = {add, add_detail};