var express = require('express');
var router = express.Router();

//增加引用函式
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.post('/', function(req, res, next) {
    var userno = req.body.userno;                       
    var reason = req.body.reason; 
    var bookingdate = req.body.bookingdate; 
    var borrowdate = req.body.borrowdate;  
    var endate = req.body.endate;       

        // 建立一個新資料物件
    var newData={
        userno:userno,
        reason:reason,
        bookingdate:bookingdate,
        borrowdate:borrowdate,
        endate:endate
    } 
        
    bookingroom.add(newData).then(d => {
        if (d==0){
            res.redirect('booking_room_detail');   //審核中
        }else{
            res.render('addFail');      //借用失敗
        }  
    })
});

module.exports = router;