var express = require('express');
var router = express.Router();

//增加引用函式
const verify = require('./utility/verify');

//接收GET請求
router.get('/', function(req, res, next) {
    //var no = "10556013";
    var no = null;

    verify.query(no).then(d => {
        if (d!=null || d!=-1){
            
            var data = {
                userno: d.userno,
                roomno: d.roomno,
                bookingroomno: d.bookingroomno,
                reason: d.reason,
                borrowdate: d.borrowdate,
                borrowtime: d.borrowtime,
                endtime: d.endtime,
                role: d.role,
                evidence: d.evidence,
                yesorno: d.yesorno
            }

            req.session.userno = d.userno;

            res.render('verify_update_form', {item:data});  //將資料傳給更新頁面
            //console.log("DATA");
        }else{
            res.render('notFound')  //導向找不到頁面
            //console.log("NULL");
        }  
    })
});

//匯出
module.exports = router;

/*
    req.session.bookingroomno = d.bookingroomno;
    console.log("req.session.bookingroomno：", req.session.bookingroomno);

    var bn = req.session.bookingroomno;
    console.log("bn：", bn);
    verify.query_detail(bn).then(d => {
        if (d!=null && d!=-1){
            var data_detail = {roomno: d.roomno}
            console.log("data_detail：", data_detail);
        }  
    })
*/