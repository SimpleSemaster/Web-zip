var express = require('express');
var router = express.Router();

//增加引用函式
const verify = require('./utility/verify');

//接收POST請求
router.post('/', function(req, res, next) {
    var userno = req.session.userno;   //取得產品編號

    var newData={
        userno:userno,                   
        yesorno: req.body.yesorno  
    } 

    console.log(newData);
    
    verify.update(newData).then(d => {
        if (d>=0){
            console.log("updateSuccess");
            //res.render('updateSuccess');
        }else{
            //console.log("updateFail");
            res.render('updateFail');
        }  
    })
});

//匯出
module.exports = router;

/*
reason: req.body.reason,   
borrowdate: req.body.borrowdate,
borrowtime: req.body.borrowtime,
endtime: req.body.endtime,
role: req.body.role,
evidence: req.body.evidence,
*/