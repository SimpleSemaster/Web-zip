var express = require('express');
var router = express.Router();

//增加引用函式
var moment = require('moment');
var today = require('silly-datetime');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.post('/', function(req, res, next) {
    var userno = req.body.userno;                       
    var reason = req.body.reason; 
    var roomno = req.body.roomno;
    var bookingdate = today.format("YYYY-MM-DD HH:mm:ss"); 
    var borrowdate = moment(req.body.borrowdate).format("YYYY-MM-DD HH:mm:ss");  
    var endate = moment(req.body.endate).format("YYYY-MM-DD HH:mm:ss");  

    var borrowweek =  moment(req.body.borrowdate).format("E");
    var endwweek =  moment(req.body.endate).format("E");

    req.session.bookingdate = bookingdate;
    req.session.roomno = roomno;

    // 建立一個新資料物件
    var newData={
        userno:userno,
        reason:reason,
        bookingdate:bookingdate,
        borrowdate:borrowdate,
        endate:endate
    } 

    console.log('userno：', userno);
    console.log('reason：', reason);
    console.log('bookingdate：', bookingdate);
    console.log('borrowdate：', borrowdate);
    console.log('endate：', endate);
    
    if(borrowdate == 'Invalid date' || endate == 'Invalid date'){
        console.log('時間不能為空值');
    }else{
        if(borrowdate >= endate){
            console.log('歸還時間不能小於借用時間');
        }else{
            if(borrowweek == '6' || borrowweek == '7' || endwweek == '6' || endwweek == '7'){
                console.log('假日無借用');
            }else{
                console.log('borrowweek：',borrowweek);
                console.log('endwweek：',endwweek);
            }
        }
        
    }
        //
    /*
    bookingroom.add(newData).then(d => {
            if (d==0){
                console.log('add：', 'addSuccess');
                res.redirect('/booking/room/query');
            }else{
                console.log('add：', 'addFail');
                res.render('addFail');
            }  
        })
    */
    
});

module.exports = router;

