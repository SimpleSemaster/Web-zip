'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//----------------------------------
// 更新商品
//----------------------------------
var update = async function(newData){
    var results;

    await sql('UPDATE bookingroom SET reason=$1, borrowdate=$2, borrowtime=$3, endtime=$4, role=$5, evidence=$6, yesorno = $7 WHERE userno = $8', [newData.reason, newData.borrowdate, newData.borrowtime, newData.endtime, newData.role, newData.evidence, newData.yesorno, newData.userno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}


//----------------------------------
// 更新商品
//----------------------------------
var update_a = async function(newData){
    var results;

    await sql('UPDATE bookingroom SET userno=$1, reason=$2, borrowdate=$3, borrowtime=$4, endtime=$5, role=$6,  evidence= $7 WHERE yesorno = $8', [newData.userno, newData.reason, newData.borrowdate, newData.borrowtime, newData.endtime, newData.role, newData.evidence, newData.yesorno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}

//------------------------------------------
//執行資料庫動作的函式-取出單一商品
//------------------------------------------
var query = async function(userno){
    var result={};
    
    await sql('SELECT * FROM "bookingroom" WHERE "userno" = $1', [userno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
		
    return result;
}

//------------------------------------------
//執行資料庫動作的函式-取出單一商品
//------------------------------------------
var query_detail = async function(bookingroomno){
    var result={};
    
    await sql('SELECT * FROM "bookingroomdetail" WHERE "bookingroomno" = $1', [bookingroomno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
		
    return result;
}
//匯出
module.exports = {update, update_a, query, query_detail};