var express = require('express');
var router = express.Router();

//增加引用函式
const verify = require('./utility/verify');

//接收GET請求
router.get('/', function(req, res, next) {
    var no = req.session.bookingroomno;

    verify.query_detail(no).then(d => {
        if (d!=null && d!=-1){
            var data = {
                roomno: d.roomno,
                
            }
            console.log("roomno", roomno);
            res.render('verify_update_form', {item:data});  //將資料傳給更新頁面
            //console.log("DATA");
        }else{
            res.render('notFound')  //導向找不到頁面
            //console.log("NULL");
        }  
    })
});

//匯出
module.exports = router;
