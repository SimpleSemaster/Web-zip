'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
//執行資料庫動作的函式-取出單一商品
//------------------------------------------
var query = async function(yesorno){
    var result={};
    
    await sql('SELECT * FROM "bookingroom" WHERE "yesorno" = $1', [yesorno])
        .then((data) => {
            if(data.rows.length > 0){
                result = data.rows[0];   
            }else{
                result = -1;
            }    
        }, (error) => {
            result = null;
        });
		
    return result;
}

//----------------------------------
// 更新商品
//----------------------------------
var update = async function(newData){
    var results;

    await sql('UPDATE "bookingroom" SET "reason"=$1, "borrowdate"=$2, "borrowtime"=$3, "endtime"=$4, "role"=$5, "evidence"=$6, "yesorno" = $7 WHERE "userno" = $8', [newData.reason, newData.borrowdate, newData.borrowtime, newData.endtime, newData.role, newData.evidence,  newData.userno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}

//匯出
module.exports = {query, update};