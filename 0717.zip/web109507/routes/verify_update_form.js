var express = require('express');
var router = express.Router();

//增加引用函式
const verify = require('./utility/verify');

//接收GET請求
router.get('/', function(req, res, next) {
    var no = req.query.yseorno;

    verify.query(no).then(d => {
        if (d!=null && d!=-1){
            var data = {
                userno: d.userno,
                reason: d.reason,
                borrowdate: d.borrowdate,
                borrowtime: d.borrowtime,
                endtime: d.endtime,
                role: d.role,
                evidence: d.evidence,
                yesorno: d.yesorno
            }

            res.render('verify_form', {item:data});  //將資料傳給更新頁面
        }else{
            res.render('notFound')  //導向找不到頁面
        }  
    })
});

//匯出
module.exports = router;