var express = require('express');
var router = express.Router();

//增加引用函式
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.get('/', function(req, res, next) {
    var borrowdate = req.session.borrowdate;
    var borrowtime = req.session.borrowtime;
    var endtime = req.session.endtime;
    var roomno = req.session.roomno;
    var yesorno = 't';
    
    bookingroom.query_borrowdate(borrowdate, borrowtime, endtime, roomno, yesorno).then(data => {
        
        if (data==null){
            console.log("此時段無人使用"); 
            //req.session.data = data;
            res.redirect('/booking/date/query');
        }else if(data==-1){
            console.log('notFound');     
            res.render('notFound');     
        }else if(data.length > 0){
            console.log(data);
            console.log("此時段有人已經借用了");
        }else{
            console.log("此時段無人使用"); 
            res.redirect('/booking/date/query');
        }
    })
});

module.exports = router;

