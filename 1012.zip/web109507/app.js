var createError = require('http-errors');
var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var cookieParser = require('cookie-parser');
var logger = require('morgan');
var bodyParser = require('body-parser');
var session = require('express-session');

var index = require('./routes/index');
var users = require('./routes/users');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');


//------------------------------------------------------------
// user使用者
//------------------------------------------------------------
var user_add_form = require('./routes/user_add_form'); //新增
var user_add = require('./routes/user_add');

var user_remove_form = require('./routes/user_remove_form');  //刪除
var user_remove = require('./routes/user_remove');

var user_query_form = require('./routes/user_query_form');  //查詢
var user_query = require('./routes/user_query');

var user_update_no = require('./routes/user_update_no');  //更新
var user_update_form = require('./routes/user_update_form');
var user_update = require('./routes/user_update');


//------------------------------------------------------------
// room教室
//------------------------------------------------------------
var room_add_form = require('./routes/room_add_form'); //新增
var room_add = require('./routes/room_add');

var room_remove_form = require('./routes/room_remove_form');  //刪除
var room_remove = require('./routes/room_remove');

var room_query_form = require('./routes/room_query_form');  //查詢
var room_query = require('./routes/room_query');

var room_update_no = require('./routes/room_update_no');  //更新
var room_update_form = require('./routes/room_update_form');
var room_update = require('./routes/room_update');


//-----------------------------------------
// bookingroom教室借用
//-----------------------------------------
var bookingroom_form = require('./routes/bookingroom_form');  //教室借用
var bookingroom = require('./routes/bookingroom');//新增
var bookingroom_verify_query = require('./routes/bookingroom_verify_query');  //查詢是否在懲罰期間
var bookingroom_date_query = require('./routes/bookingroom_date_query');  //查詢bookingroomno
var bookingroom_detail_add = require('./routes/bookingroom_detail_add');  //新增roomno&bookingroomno
var bookingroom_borrowdate_query = require('./routes/bookingroom_borrowdate_query');


//------------------------------------------------------------
// roomverify教室審核
//------------------------------------------------------------
var roomverify_update_no = require('./routes/roomverify_update_no');
var roomverify_update_form = require('./routes/roomverify_update_form');
var roomverify_update = require('./routes/roomverify_update');

var roomverify_query_form = require('./routes/roomverify_query_form');  //查詢
var roomverify_query = require('./routes/roomverify_query');

//var mail = require('./routes/mail'); 


//-----------------------------------------
// device設備
//-----------------------------------------
var device_add_form = require('./routes/device_add_form'); //新增
var device_add = require('./routes/device_add');

var device_remove_form = require('./routes/device_remove_form');  //刪除
var device_remove = require('./routes/device_remove');

var device_query_form = require('./routes/device_query_form');  //查詢
var device_query = require('./routes/device_query');

var device_update_no = require('./routes/device_update_no');  //更新
var device_update_form = require('./routes/device_update_form');
var device_update = require('./routes/device_update');


//-----------------------------------------
// bookingdevice設備借用
//-----------------------------------------
var bookingdevice_form = require('./routes/bookingdevice_form');  //設備借用
var bookingdevice = require('./routes/bookingdevice');//新增 
var bookingdevice_verify_query = require('./routes/bookingdevice_verify_query');  //查詢是否在懲罰期間
var bookingdevice_date_query = require('./routes/bookingdevice_date_query');  //查詢bookingdeviceno
var bookingdevice_detail_add = require('./routes/bookingdevice_detail_add');  //新增bookingdeviceno


//-----------------------------------------
// punish懲罰
//-----------------------------------------
var punish_add_form = require('./routes/punish_add_form'); //新增
var punish_add = require('./routes/punish_add');

var punish_remove_form = require('./routes/punish_remove_form');  //刪除
var punish_remove = require('./routes/punish_remove');

var punish_query_form = require('./routes/punish_query_form');  //查詢
var punish_query = require('./routes/punish_query');

var punish_update_no = require('./routes/punish_update_no');  //更新
var punish_update_form = require('./routes/punish_update_form');
var punish_update = require('./routes/punish_update');


//------------------------------------------------------------
// auth&logou權限及登出
//------------------------------------------------------------
var user_type = require('./routes/user_type');    //類型
var checkAuth_E = require('./routes/checkAuth_E');  //權限(是否為員工)
var checkAuth_ST = require('./routes/checkAuth_ST');  //權限(是否為本系師生)
var logout = require('./routes/logout');    //登出


var app = express();
//---------------------------------------------
// 使用passport-google-oauth2套件進行認證
//---------------------------------------------
/**/
var passport = require('passport');

app.use(require('express-session')({
    secret: 'keyboard cat',
    resave: true,
    saveUninitialized: true
}));

app.use(passport.initialize());
app.use(passport.session());

passport.serializeUser(function(user, done) {
    done(null, user);
});

passport.deserializeUser(function(user, done) {
    done(null, user);
});

//載入google oauth2
var GoogleStrategy = require('passport-google-oauth20').Strategy;

//填入自己在google cloud platform建立的憑證
passport.use(
    new GoogleStrategy({
        clientID: '11686802778-1uhbpv4706p3an8anm8qs4dcah4v7t4n.apps.googleusercontent.com', 
        clientSecret: '82gW3jPvKOVPPUzqt9bCW-SN',
        callbackURL: "https://simple-semaster.herokuapp.com/auth/google/callback"
        //callbackURL: "http://localhost/auth/google/callback"  //localhost
    },
    function(accessToken, refreshToken, profile, done) {
      console.log(profile);
        if (profile) {
            return done(null, profile);
        }else {
            return done(null, false);
        }
        
    }
));


// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({secret: '請更改成一個隨機字串用來加密產生的signedCookie', cookie: { maxAge: 60000 }}));

app.use('/', index);
app.use('/users', users);

app.use('/', indexRouter);
app.use('/users', usersRouter);


//-----------------------------------------
// user使用者
//-----------------------------------------
app.use('/user/add/form', checkAuth_E, user_add_form); //新增
app.use('/user/add', checkAuth_E, user_add);

app.use('/user/remove/form', checkAuth_E, user_remove_form); //刪除
app.use('/user/remove', checkAuth_E, user_remove);

app.use('/user/query/form', checkAuth_E, user_query_form); //查詢
app.use('/user/query', checkAuth_E, user_query);

app.use('/user/update/no', checkAuth_E, user_update_no); //更新
app.use('/user/update/form', checkAuth_E, user_update_form);
app.use('/user/update', checkAuth_E, user_update);


//-----------------------------------------
// room教室
//-----------------------------------------
app.use('/room/add/form', checkAuth_E, room_add_form); //新增
app.use('/room/add', checkAuth_E, room_add);

app.use('/room/remove/form', checkAuth_E, room_remove_form); //刪除
app.use('/room/remove', checkAuth_E, room_remove);

app.use('/room/query/form', checkAuth_E, room_query_form); //查詢
app.use('/room/query', checkAuth_E, room_query);

app.use('/room/update/no', checkAuth_E, room_update_no); //更新
app.use('/room/update/form', checkAuth_E, room_update_form);
app.use('/room/update', checkAuth_E, room_update);


//-----------------------------------------
// bookingroom教室借用
//-----------------------------------------
app.use('/bookingroom/form', bookingroom_form); //教室借用
app.use('/bookingroom', bookingroom); //新增
app.use('/bookingroom/verify/query', bookingroom_verify_query); //查詢是否在懲罰期間
app.use('/bookingroom/date/query', bookingroom_date_query); //查詢bookingroomno
app.use('/bookingroom/detail/add', bookingroom_detail_add); //新增roomno&bookingroomno
app.use('/bookingroom/borrowdate/query', bookingroom_borrowdate_query);


//-----------------------------------------
// device設備
//-----------------------------------------
app.use('/device/add/form', checkAuth_E, device_add_form); //新增
app.use('/device/add', checkAuth_E, device_add);

app.use('/device/remove/form', checkAuth_E, device_remove_form); //刪除
app.use('/device/remove', checkAuth_E, device_remove);

app.use('/device/query/form', checkAuth_E, device_query_form); //查詢
app.use('/device/query', checkAuth_E, device_query);

app.use('/device/update/no', checkAuth_E, device_update_no); //更新
app.use('/device/update/form', checkAuth_E, device_update_form);
app.use('/device/update', checkAuth_E, device_update);


//-----------------------------------------
// bookingdevice設備借用
//-----------------------------------------
app.use('/bookingdevice/form', bookingdevice_form); //設備借用
app.use('/bookingdevice', bookingdevice); //新增
app.use('/bookingdevice/verify/query', bookingdevice_verify_query); //查詢是否在懲罰期間
app.use('/bookingdevice/date/query', bookingdevice_date_query); //查詢bookingdeviceno
app.use('/bookingdevice/detail/add', bookingdevice_detail_add); //新增bookingdeviceno


//------------------------------------------------------------
// roomverify教室審核
//------------------------------------------------------------
app.use('/roomverify/update/no', roomverify_update_no);
app.use('/roomverify/update/form', roomverify_update_form);
app.use('/roomverify/update', roomverify_update);

app.use('/roomverify/query/form', roomverify_query_form); //查詢
app.use('/roomverify/query', roomverify_query);

//app.use('/mail', mail);


//-----------------------------------------
// punish懲罰
//-----------------------------------------
app.use('/punish/add/form', checkAuth_E, punish_add_form); //新增
app.use('/punish/add', checkAuth_E, punish_add);

app.use('/punish/remove/form', checkAuth_E, punish_remove_form); //刪除
app.use('/punish/remove', checkAuth_E, punish_remove);

app.use('/punish/query/form', checkAuth_ST, punish_query_form); //查詢
app.use('/punish/query', checkAuth_ST, punish_query);

app.use('/punish/update/no', checkAuth_E, punish_update_no); //更新
app.use('/punish/update/form', checkAuth_E, punish_update_form);
app.use('/punish/update', checkAuth_E, punish_update);


//------------------------------------------------------------
// auth&logout
//------------------------------------------------------------
app.use('/user_type', user_type); //類型
app.use('/logout', logout); //登出


app.use(require('express-session')({ secret: 'keyboard cat', resave: true, saveUninitialized: true }));
app.use(passport.initialize());
app.use(passport.session());


//-----------------------------------------------------------------------------------
// Get profile from google
//-----------------------------------------------------------------------------------
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile','email'] }));

app.get('/auth/google/callback', 
  passport.authenticate('google', { failureRedirect: '/login' }),
  function(req, res) {
    // Successful authentication, redirect home.
    console.log(req.session.passport.user.id);                //ID
    console.log(req.session.passport.user.displayName);       //姓名
    console.log(req.session.passport.user.emails[0].value);	  //帳號
    req.session.email = req.session.passport.user.emails[0].value;  //把帳號放到session裡，之後都從session抓就號
    res.redirect('/user_type');
  });

app.get('/user/logout', function(req, res){    
    req.logout();        //將使用者資料從session移除
    res.redirect('/logout');   //導向登出頁面
  });    



// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};

  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

module.exports = app;
