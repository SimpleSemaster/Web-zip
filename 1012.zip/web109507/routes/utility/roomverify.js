'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
//查詢所有相關資料
//------------------------------------------
var query = async function(yesorno){
    var result={};

    await sql('SELECT * FROM bookingroom as a JOIN bookingroomdetail as b on a.bookingroomno = b.bookingroomno WHERE yesorno is null or a.yesorno = $1 ORDER BY a.bookingroomno, a."role"', [yesorno])
        .then((data) => {
            result = data.rows;
        }, (error) => {
            result = null;
        });       
    console.log(result);
    
    return result;
}

//----------------------------------
// 更新商品
//----------------------------------
var update = async function(newData){
    var results;

    await sql('UPDATE bookingroom SET yesorno=$1 WHERE bookingroomno = $2 and userno = $3', [newData.yesorno, newData.bookingroomno, newData.userno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}

//------------------------------------------
//執行資料庫動作的函式-取出單一商品
//------------------------------------------
var query_no = async function(userno){
    var result={};
    
    await sql('SELECT * FROM (bookingroom as a JOIN bookingroomdetail as b on a.bookingroomno = b.bookingroomno) JOIN room as c on b.roomno = c.roomno WHERE a.userno = $1', [userno])
        .then((data) => {
            result = data.rows;   
        }, (error) => {
            result = null;
        });


    console.log(result);
    return result;

    
}

//匯出
module.exports = {query, update, query_no};