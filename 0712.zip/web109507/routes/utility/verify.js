'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//----------------------------------
// 更新商品
//----------------------------------
var update = async function(newData){
    var results;

    await sql('UPDATE "bookingroom" SET "reason"=$1, "borrowdate"=$2, "borrowtime"=$3, "endtime"=$4, "role"=$5, "evidence"=$6, "yesorno" = $7 WHERE "userno" = $8', [newData.reason, newData.borrowdate, newData.borrowtime, newData.endtime, newData.role, newData.evidence,  newData.userno])
        .then((data) => {
            results = data.rowCount;  
        }, (error) => {
            results = -1;
        });
		
    return results;
}

//匯出
module.exports = {update};