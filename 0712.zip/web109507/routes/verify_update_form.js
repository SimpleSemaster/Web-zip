var express = require('express');
var router = express.Router();

//增加引用函式
const verify = require('./utility/verify');



//匯出
module.exports = router;