function save(){
    var db = openDatabase('contactdb','','local database demo',204800);
    var user_name = googleUser.getBasicProfile().getName().value;
    var userno = googleUer.getBasicProfile().getId().value;
    var spinner = document.getElementById("spinner").value;
	//建立時間
	var time = new Date().getTime();
	db.transaction(function(tx){
    tx.executeSql('insert into contact values(?,?,?,?)',[user_name,mobilephone,company,time],onSuccess,onError);
	});
	}
	//sql語句執行成功後執行的回撥函式
	function onSuccess(tx,rs){
	alert("操作成功");
    loadAll();
    location.href = "../projectmrt/index.html";
	}
	//sql語句執行失敗後執行的回撥函式
	function onError(tx,error){
    alert("操作失敗,失敗資訊:"+ error.message);  
    }