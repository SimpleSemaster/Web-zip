var express = require('express');
var router = express.Router();

//增加引用函式
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.get('/', function(req, res, next) {
    var date = req.session.bookingdate;
    
    bookingroom.query(date).then(data => {
        if (data==null){
           console.log('error');  //導向錯誤頁面
           res.render('error');
        }else if(data==-1){
            console.log('notFound');     
            res.render('notFound');     
        }else{
            console.log('data：',data); 
            req.session.data = data;
            //res.redirect('/booking/detail/add');
            res.redirect('/booking/borrowdate/query');
        }  
    })
});

module.exports = router;

