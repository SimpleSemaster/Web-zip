var express = require('express');
var router = express.Router();

//增加引用函式
const verify = require('./utility/verify');

//接收POST請求
router.post('/', function(req, res, next) {
    var bookingroomno = req.body.bookingroomno;   //取得借用編號
    var userno = req.body.userno;   //取得使用者編號

    var newData={
        bookingroomno:bookingroomno,
        userno:userno,                   
        yesorno: req.body.yesorno  
    } 

    console.log(newData);
    
    verify.update(newData).then(d => {
        if (d>=0){
            console.log("updateSuccess");
            //res.render('updateSuccess');
            //res.redirect('/mail');
        }else{
            console.log("updateFail");
            //res.render('updateFail');
        }  
    })
});

//匯出
module.exports = router;

/*
reason: req.body.reason,   
borrowdate: req.body.borrowdate,
borrowtime: req.body.borrowtime,
endtime: req.body.endtime,
role: req.body.role,
evidence: req.body.evidence,
*/