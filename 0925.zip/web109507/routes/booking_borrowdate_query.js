var express = require('express');
var router = express.Router();

//增加引用函式
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.get('/', function(req, res, next) {
    var borrowdate = req.session.borrowdate;
    
    bookingroom.query_borrowdate(borrowdate).then(data => {
        if (data==null){
            console.log("此時段無人使用"); 
            //req.session.data = data;
            //res.redirect('/booking/detail/add');
        }else if(data==-1){
            console.log('notFound');     
            res.render('notFound');     
        }else{
            console.log("此時段有人已經借用了");
        }
    })
});

module.exports = router;

