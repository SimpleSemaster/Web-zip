'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
// 新增商品
//------------------------------------------
var add = async function(newData){
    var result;

    await sql('INSERT INTO bookingroom (userno, bookingroomno, reason, bookingdate, borrowdate, returndate) VALUES ($1, $2, $3, $4, $5, $6)', [newData.userno, newData.bookingroomno, newData.reason, newData.bookingdate, newData.borrowdate, newData.returndate])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
		
    return result;
}

//匯出
module.exports = {add};