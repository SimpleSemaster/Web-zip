var express = require('express');
var router = express.Router();

//增加引用函式
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.post('/', function(req, res, next) {
    var userno = req.body.userno;               
    var bookingroomno = req.body.bookingroomno;           
    var reason = req.body.reason; 
    var bookingdate = req.body.bookingdate; 
    var userno = req.body.userno;  
    var userno = req.body.userno;       

    if(bookingroom.bookingdate == bookingdate && bookingroom.borrowdate){
        // 建立一個新資料物件
        var newData={
            userno:userno,
            bookingroomno:bookingroomno,
            reason:reason,
            bookingdate:bookingdate,
            borrowdate:borrowdate,
            returndate:returndate
        } 
        
        bookingroom.add(newData).then(d => {
            if (d==0){
                res.render('addSuccess');   //審核中
            }else{
                res.render('addFail');      //借用失敗
            }  
        })
    }else{
        res.render('addFail');   //已被借用
    }
});



module.exports = router;