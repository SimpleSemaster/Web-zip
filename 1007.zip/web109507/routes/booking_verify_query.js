var express = require('express');
var router = express.Router();

//增加引用函式
var moment = require('moment');
const bookingroom = require('./utility/bookingroom');

//接收POST請求
router.get('/', function(req, res, next) {
    var userno = req.session.userno;
    var borrowdate = req.session.borrowdate;
    
    bookingroom.query_verify(userno).then(data => {
        if (data==null){
           console.log('error');  //導向錯誤頁面
           res.render('error');
        }else if(data==-1){
            res.redirect('/booking/borrowdate/query');
            console.log("未有違規事項");   
        }else{
            var data = {
                userno: userno,
                startdate:  moment(data.startdate).format("YYYY-MM-DD"),   //懲罰開始日
                finishdate: moment(data.finishdate).format("YYYY-MM-DD")    //懲罰結束日
            }
            console.log(data);
            if(borrowdate > data.startdate || borrowdate < data.finishdate){ 
                console.log("在懲罰期間不能借用");
                res.render('inPunish');
            }else{
                res.redirect('/booking/borrowdate/query');
                console.log("未有違規事項");
            }
        }  
    })
});

module.exports = router;

