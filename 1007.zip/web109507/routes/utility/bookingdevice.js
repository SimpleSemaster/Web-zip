'use strict';

//引用操作資料庫的物件
const sql = require('./asyncDB');

//------------------------------------------
// 新增商品
//------------------------------------------
var add = async function(newData){
    var result={};

    await sql('INSERT INTO bookingdevice (userno, category, bookingdate, borrowdate, returndate, teleno) VALUES ($1, $2, $3, $4, $5, $6)', [newData.userno, newData.category, newData.bookingdate, newData.borrowdate, newData.returndate, newData.teleno])
        .then((data) => {
            result = 0;  
        }, (error) => {
            result = -1;
        });
        
    console.log(result);
    return result;
}

//匯出
module.exports = {add};